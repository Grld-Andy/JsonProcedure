import { useState } from 'react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { connectionApi, type ConnectionSettings, type ConnectionStatus } from '@/lib/api'
import { errMsg, Field, NativeSelect } from '@/components/shared'

export function ConnectionPage({ status, onChanged }: { status: ConnectionStatus | null; onChanged: () => void }) {
  const [mode, setMode] = useState<'form' | 'string'>('form')
  const [server, setServer] = useState(status?.server && status.connected ? status.server : 'localhost')
  const [port, setPort] = useState('')
  const [database, setDatabase] = useState(status?.database || 'JsonProcedure')
  const [authType, setAuthType] = useState<'windows' | 'sql'>(status?.authType ?? 'windows')
  const [user, setUser] = useState(status?.user ?? '')
  const [password, setPassword] = useState('')
  const [trust, setTrust] = useState(true)
  const [encrypt, setEncrypt] = useState(false)
  const [raw, setRaw] = useState(
    'Server=localhost;Database=JsonProcedure;Trusted_Connection=True;TrustServerCertificate=True;',
  )
  const [createDb, setCreateDb] = useState(true)
  const [busy, setBusy] = useState(false)
  const [testMsg, setTestMsg] = useState<{ ok: boolean; text: string } | null>(null)

  const settings = (): ConnectionSettings =>
    mode === 'string'
      ? { connectionString: raw, createDatabase: createDb }
      : {
          server, database, authType, user, password,
          port: port ? Number(port) : undefined,
          trustServerCertificate: trust, encrypt, createDatabase: createDb,
        }

  const test = async () => {
    setBusy(true); setTestMsg(null)
    try {
      const r = await connectionApi.test(settings())
      if (!r.serverReachable) setTestMsg({ ok: false, text: r.error ?? 'Server unreachable' })
      else if (!r.databaseExists)
        setTestMsg({ ok: true, text: 'Server reachable, but the database does not exist yet (it is created when you connect, if the box is ticked).' })
      else setTestMsg({ ok: true, text: 'Connection successful.' })
    } catch (e) { setTestMsg({ ok: false, text: errMsg(e) }) } finally { setBusy(false) }
  }

  const connect = async () => {
    setBusy(true)
    try {
      await connectionApi.apply(settings())
      toast.success('Connected and saved')
      setTestMsg(null)
      onChanged()
    } catch (e) { toast.error(errMsg(e)) } finally { setBusy(false) }
  }

  return (
    <div className="grid max-w-2xl gap-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Current connection
            <Badge variant={status?.connected ? 'default' : 'destructive'}>{status?.connected ? 'connected' : 'not connected'}</Badge>
          </CardTitle>
          <CardDescription>
            {status?.server
              ? `${status.server} / ${status.database} (${status.authType === 'sql' ? `SQL login ${status.user}` : 'Windows auth'})`
              : 'No connection configured yet.'}
          </CardDescription>
        </CardHeader>
        {status?.error && <CardContent><p className="text-sm text-destructive">{status.error}</p></CardContent>}
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Connect to a database</CardTitle>
          <CardDescription>
            Fill in the details or paste a full connection string. The connection is saved locally in server/connection.local.json (plain text) and reused on restart.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="flex gap-2">
            <Button variant={mode === 'form' ? 'default' : 'outline'} size="sm" onClick={() => setMode('form')}>Details</Button>
            <Button variant={mode === 'string' ? 'default' : 'outline'} size="sm" onClick={() => setMode('string')}>Connection string</Button>
          </div>

          {mode === 'string' ? (
            <Field label="Connection string">
              <Textarea rows={4} value={raw} onChange={e => setRaw(e.target.value)} className="font-mono text-xs" />
            </Field>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              <Field label="Server / host">
                <Input value={server} onChange={e => setServer(e.target.value)} placeholder="localhost or (localdb)\MSSQLLocalDB" />
              </Field>
              <Field label="Port (optional, default 1433)">
                <Input value={port} onChange={e => setPort(e.target.value.replace(/\D/g, ''))} placeholder="1433" />
              </Field>
              <Field label="Database name" className="col-span-2">
                <Input value={database} onChange={e => setDatabase(e.target.value)} />
              </Field>
              <Field label="Authentication" className="col-span-2">
                <NativeSelect value={authType} onChange={e => setAuthType(e.target.value as 'windows' | 'sql')}>
                  <option value="windows">Windows authentication</option>
                  <option value="sql">SQL Server login (user + password)</option>
                </NativeSelect>
              </Field>
              {authType === 'sql' && (
                <>
                  <Field label="User"><Input value={user} onChange={e => setUser(e.target.value)} autoComplete="off" /></Field>
                  <Field label="Password">
                    <Input type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="new-password" />
                  </Field>
                </>
              )}
              <div className="col-span-2 flex flex-wrap gap-6">
                <Label className="flex items-center gap-2"><Checkbox checked={trust} onCheckedChange={v => setTrust(!!v)} /> Trust server certificate</Label>
                <Label className="flex items-center gap-2"><Checkbox checked={encrypt} onCheckedChange={v => setEncrypt(!!v)} /> Encrypt</Label>
              </div>
            </div>
          )}

          <Label className="flex items-center gap-2">
            <Checkbox checked={createDb} onCheckedChange={v => setCreateDb(!!v)} /> Create the database if it does not exist
          </Label>

          {testMsg && <p className={testMsg.ok ? 'text-sm text-emerald-600' : 'text-sm text-destructive'}>{testMsg.text}</p>}

          <div className="flex gap-2">
            <Button variant="outline" onClick={test} disabled={busy}>Test connection</Button>
            <Button onClick={connect} disabled={busy}>Connect &amp; save</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
