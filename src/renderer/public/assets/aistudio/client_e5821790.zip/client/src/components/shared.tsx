import { useState, type ReactNode, type SelectHTMLAttributes } from 'react'
import { Copy, Download } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { cn } from '@/lib/utils'
import { resultToJson, type ExecutionResult, type ResultSet } from '@/lib/api'

export function NativeSelect({ className, ...props }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={cn(
        'h-8 w-full rounded-lg border border-input bg-transparent px-2 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 dark:bg-input/30',
        className,
      )}
    />
  )
}

export function Field({ label, children, className }: { label: string; children: ReactNode; className?: string }) {
  return (
    <div className={cn('grid gap-1.5', className)}>
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      {children}
    </div>
  )
}

export function errMsg(e: unknown) {
  return e instanceof Error ? e.message : String(e)
}

export function JsonView({ value, maxHeight = 420 }: { value: unknown; maxHeight?: number }) {
  const text = JSON.stringify(value, null, 2) ?? 'null'
  const copy = async () => {
    await navigator.clipboard.writeText(text)
    toast.success('JSON copied')
  }
  const download = () => {
    const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }))
    const a = document.createElement('a')
    a.href = url
    a.download = 'result.json'
    a.click()
    URL.revokeObjectURL(url)
  }
  return (
    <div className="grid gap-2">
      <div className="flex justify-end gap-2">
        <Button size="sm" variant="outline" onClick={copy}><Copy /> Copy</Button>
        <Button size="sm" variant="outline" onClick={download}><Download /> Download</Button>
      </div>
      <pre className="overflow-auto rounded-lg border bg-muted/40 p-3 font-mono text-xs" style={{ maxHeight }}>{text}</pre>
    </div>
  )
}

function cell(v: unknown) {
  if (v === null || v === undefined) return <span className="text-muted-foreground italic">NULL</span>
  if (typeof v === 'object') return JSON.stringify(v)
  return String(v)
}

export function DataGrid({ set, maxHeight = 360 }: { set: ResultSet; maxHeight?: number }) {
  if (set.json !== null && set.json !== undefined) return <JsonView value={set.json} maxHeight={maxHeight} />
  if (set.columns.length === 0) return <p className="text-sm text-muted-foreground">No columns.</p>
  return (
    <div className="overflow-auto rounded-lg border" style={{ maxHeight }}>
      <Table>
        <TableHeader>
          <TableRow>{set.columns.map(c => <TableHead key={c}>{c}</TableHead>)}</TableRow>
        </TableHeader>
        <TableBody>
          {set.rows.length === 0 && (
            <TableRow><TableCell colSpan={set.columns.length} className="text-muted-foreground">No rows</TableCell></TableRow>
          )}
          {set.rows.map((r, i) => (
            <TableRow key={i}>{set.columns.map(c => <TableCell key={c} className="whitespace-nowrap">{cell(r[c])}</TableCell>)}</TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

export function ExecutionView({ result }: { result: ExecutionResult }) {
  const [tab, setTab] = useState('json')
  return (
    <div className="grid gap-3">
      <p className="text-xs text-muted-foreground">
        {result.resultSets.length} result set(s) · {result.elapsedMs} ms
        {result.returnValue !== null && ` · return value ${result.returnValue}`}
      </p>
      <Tabs value={tab} onValueChange={v => setTab(String(v))}>
        <TabsList>
          <TabsTrigger value="json">JSON</TabsTrigger>
          <TabsTrigger value="table">Tables</TabsTrigger>
        </TabsList>
        <TabsContent value="json"><JsonView value={resultToJson(result)} /></TabsContent>
        <TabsContent value="table">
          <div className="grid gap-4">
            {result.resultSets.map((s, i) => (
              <div key={i} className="grid gap-1">
                <span className="text-xs font-medium text-muted-foreground">Result set {i + 1}</span>
                <DataGrid set={s} />
              </div>
            ))}
            {Object.keys(result.outputParameters).length > 0 && (
              <div className="grid gap-1">
                <span className="text-xs font-medium text-muted-foreground">Output parameters</span>
                <JsonView value={result.outputParameters} maxHeight={160} />
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
