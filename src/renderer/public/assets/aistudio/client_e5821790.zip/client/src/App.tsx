import { useCallback, useEffect, useState } from 'react'
import { Database } from 'lucide-react'
import { Toaster } from '@/components/ui/sonner'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { connectionApi, type ConnectionStatus } from '@/lib/api'
import { ConnectionPage } from '@/pages/ConnectionPage'
import { ProceduresPage } from '@/pages/ProceduresPage'
import { TablesPage } from '@/pages/TablesPage'

export default function App() {
  const [status, setStatus] = useState<ConnectionStatus | null>(null)
  const [tab, setTab] = useState('procedures')
  const [refreshKey, setRefreshKey] = useState(0)
  const [loaded, setLoaded] = useState(false)

  const refresh = useCallback(async () => {
    try {
      const s = await connectionApi.status()
      setStatus(s)
      return s
    } catch {
      setStatus(null)
      return null
    } finally { setLoaded(true) }
  }, [])

  useEffect(() => {
    void refresh().then(s => { if (!s?.connected) setTab('connection') })
  }, [refresh])

  const onConnectionChanged = async () => {
    const s = await refresh()
    setRefreshKey(k => k + 1)
    if (s?.connected) setTab('procedures')
  }

  return (
    <div className="mx-auto min-h-screen max-w-7xl px-4 py-6">
      <header className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Database className="size-6" />
          <h1 className="text-xl font-semibold">JsonProcedure</h1>
          <span className="text-sm text-muted-foreground">stored procedures → JSON</span>
        </div>
        {loaded && (
          <Badge variant={status?.connected ? 'secondary' : 'destructive'} title={status?.error ?? undefined}>
            {status?.connected ? `${status.server} / ${status.database}` : 'not connected'}
          </Badge>
        )}
      </header>

      <Tabs value={tab} onValueChange={v => setTab(String(v))}>
        <TabsList>
          <TabsTrigger value="procedures">Procedures</TabsTrigger>
          <TabsTrigger value="tables">Tables</TabsTrigger>
          <TabsTrigger value="connection">Connection</TabsTrigger>
        </TabsList>
        <TabsContent value="procedures">
          {status?.connected ? <ProceduresPage refreshKey={refreshKey} /> : <NeedConnection />}
        </TabsContent>
        <TabsContent value="tables">
          {status?.connected ? <TablesPage refreshKey={refreshKey} /> : <NeedConnection />}
        </TabsContent>
        <TabsContent value="connection">
          <ConnectionPage status={status} onChanged={onConnectionChanged} />
        </TabsContent>
      </Tabs>
      <Toaster richColors position="bottom-right" />
    </div>
  )
}

function NeedConnection() {
  return <p className="text-sm text-muted-foreground">Connect to a database first (Connection tab).</p>
}
