export type Json = unknown

export interface ForeignKeyRef { schema?: string; table: string; column: string }

export interface ColumnDef {
  name: string
  type: string
  length?: string | null
  precision?: number | null
  scale?: number | null
  nullable: boolean
  primaryKey: boolean
  identity: boolean
  unique: boolean
  default?: string | null
  check?: string | null
  references?: ForeignKeyRef | null
}

export interface TableColumnInfo {
  name: string; type: string; nullable: boolean; primaryKey: boolean; identity: boolean
  unique: boolean; computed: boolean; default: string | null; references: string | null
}
export interface TableInfo { schema: string; name: string; rowCount: number; columns: TableColumnInfo[] }

export interface ProcedureSummary { schema: string; name: string; created: string; modified: string; parameterCount: number }
export interface ProcedureParameter { name: string; type: string; isOutput: boolean; hasDefault: boolean }
export interface ProcedureDetail {
  schema: string; name: string; definition: string | null; isEncrypted: boolean; parameters: ProcedureParameter[]
}

export interface ResultSet { columns: string[]; rows: Record<string, unknown>[]; json: Json | null }
export interface ExecutionResult {
  resultSets: ResultSet[]
  outputParameters: Record<string, unknown>
  returnValue: number | null
  rowsAffected: number
  elapsedMs: number
}

async function request<T>(method: string, url: string, body?: unknown): Promise<T> {
  const res = await fetch(url, {
    method,
    headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  })
  if (!res.ok) {
    let msg = `${res.status} ${res.statusText}`
    try { const j = await res.json(); if (j?.error) msg = j.error; else if (j?.title) msg = j.title } catch { /* ignore */ }
    throw new Error(msg)
  }
  if (res.status === 204) return undefined as T
  return res.json() as Promise<T>
}

const enc = encodeURIComponent

export const api = {
  tables: () => request<TableInfo[]>('GET', '/api/tables'),
  previewTable: (t: { schema?: string; name: string; columns: ColumnDef[] }) =>
    request<{ sql: string }>('POST', '/api/tables/preview', t),
  createTable: (t: { schema?: string; name: string; columns: ColumnDef[] }) =>
    request<{ sql: string }>('POST', '/api/tables', t),
  infer: (rows: Record<string, unknown>[]) => request<ColumnDef[]>('POST', '/api/tables/infer', { rows }),
  dropTable: (s: string, n: string) => request<void>('DELETE', `/api/tables/${enc(s)}/${enc(n)}`),
  rows: (s: string, n: string, top = 100) => request<ResultSet>('GET', `/api/tables/${enc(s)}/${enc(n)}/rows?top=${top}`),
  insertRow: (s: string, n: string, values: Record<string, unknown>) =>
    request<{ inserted: number }>('POST', `/api/tables/${enc(s)}/${enc(n)}/rows`, { values }),
  importRows: (s: string, n: string, rows: Record<string, unknown>[]) =>
    request<{ inserted: number }>('POST', `/api/tables/${enc(s)}/${enc(n)}/import`, { rows }),

  procedures: () => request<ProcedureSummary[]>('GET', '/api/procedures'),
  procedure: (s: string, n: string) => request<ProcedureDetail>('GET', `/api/procedures/${enc(s)}/${enc(n)}`),
  saveProcedure: (script: string) => request<{ saved: boolean }>('POST', '/api/procedures', { script }),
  dropProcedure: (s: string, n: string) => request<void>('DELETE', `/api/procedures/${enc(s)}/${enc(n)}`),
  execute: (s: string, n: string, parameters: Record<string, unknown>) =>
    request<ExecutionResult>('POST', `/api/procedures/${enc(s)}/${enc(n)}/execute`, { parameters }),
}

/** Combine result sets into a single JSON value (one set -> array of rows, many -> array of arrays). */
export function resultToJson(r: ExecutionResult): Json {
  const sets = r.resultSets.map(s => (s.json !== null && s.json !== undefined ? s.json : s.rows))
  const body = sets.length === 1 ? sets[0] : sets
  const hasExtras = Object.keys(r.outputParameters).length > 0 || r.returnValue !== null
  return hasExtras ? { results: body, outputParameters: r.outputParameters, returnValue: r.returnValue } : body
}

// ---- connection -----------------------------------------------------------
export interface ConnectionStatus {
  connected: boolean; error: string | null; server: string | null; database: string | null
  authType: 'windows' | 'sql'; user: string | null; hasPassword: boolean
  trustServerCertificate: boolean; encrypt: boolean; connectionString: string
}
export interface ConnectionSettings {
  connectionString?: string
  server?: string; port?: number; database?: string
  authType?: 'windows' | 'sql'; user?: string; password?: string
  trustServerCertificate?: boolean; encrypt?: boolean
  createDatabase?: boolean
}
export const connectionApi = {
  status: () => request<ConnectionStatus>('GET', '/api/connection'),
  test: (s: ConnectionSettings) =>
    request<{ serverReachable: boolean; databaseExists: boolean; error: string | null }>('POST', '/api/connection/test', s),
  apply: (s: ConnectionSettings) => request<ConnectionStatus>('PUT', '/api/connection', s),
}
