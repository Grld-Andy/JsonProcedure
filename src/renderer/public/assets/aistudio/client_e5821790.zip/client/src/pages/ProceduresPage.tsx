import { useCallback, useEffect, useState } from 'react'
import { Play, Plus, RefreshCw, Save, Trash2 } from 'lucide-react'
import { toast } from 'sonner'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { api, type ExecutionResult, type ProcedureDetail, type ProcedureSummary } from '@/lib/api'
import { errMsg, ExecutionView, Field } from '@/components/shared'

const TEMPLATE = `CREATE OR ALTER PROCEDURE dbo.MyProcedure
    @Id int = NULL
AS
BEGIN
    SET NOCOUNT ON;
    -- Return rows; add FOR JSON PATH to get JSON straight from SQL Server
    SELECT 1 AS Id, N'hello' AS Message;
END`

/** Convert a stored definition (CREATE ...) into a re-runnable CREATE OR ALTER script. */
function toAlterable(def: string) {
  return def.replace(/^(\s*(?:--[^\n]*\n|\/\*[\s\S]*?\*\/|\s)*)CREATE\s+PROC(EDURE)?/i, '$1CREATE OR ALTER PROCEDURE')
}

function coerce(type: string, text: string): unknown {
  const t = text.trim()
  if (t.toLowerCase() === 'null') return null
  const base = type.replace(/\(.*\)/, '')
  if (['int', 'bigint', 'smallint', 'tinyint', 'decimal', 'numeric', 'float', 'real', 'money', 'smallmoney'].includes(base)) {
    const n = Number(t)
    if (Number.isNaN(n)) throw new Error(`"${text}" is not a number`)
    return n
  }
  if (base === 'bit') return ['1', 'true', 'yes'].includes(t.toLowerCase())
  return text
}

export function ProceduresPage({ refreshKey }: { refreshKey: number }) {
  const [list, setList] = useState<ProcedureSummary[]>([])
  const [selected, setSelected] = useState<{ schema: string; name: string } | null>(null)
  const [detail, setDetail] = useState<ProcedureDetail | null>(null)
  const [script, setScript] = useState(TEMPLATE)
  const [values, setValues] = useState<Record<string, string>>({})
  const [result, setResult] = useState<ExecutionResult | null>(null)
  const [busy, setBusy] = useState(false)
  const [filter, setFilter] = useState('')

  const load = useCallback(async () => {
    try { setList(await api.procedures()) } catch (e) { toast.error(errMsg(e)); setList([]) }
  }, [])
  useEffect(() => { void load() }, [load, refreshKey])

  const open = async (p: { schema: string; name: string }) => {
    try {
      const d = await api.procedure(p.schema, p.name)
      setSelected(p); setDetail(d); setValues({}); setResult(null)
      setScript(d.definition ? toAlterable(d.definition) : '-- This procedure is encrypted; its definition cannot be read.')
    } catch (e) { toast.error(errMsg(e)) }
  }

  const newProc = () => { setSelected(null); setDetail(null); setValues({}); setResult(null); setScript(TEMPLATE) }

  const save = async () => {
    setBusy(true)
    try {
      await api.saveProcedure(script)
      toast.success('Procedure saved')
      await load()
      const m = /PROC(?:EDURE)?\s+(?:\[?(\w+)\]?\s*\.\s*)?\[?(\w+)\]?/i.exec(script)
      if (m) await open({ schema: m[1] ?? 'dbo', name: m[2] })
    } catch (e) { toast.error(errMsg(e)) } finally { setBusy(false) }
  }

  const run = async () => {
    if (!selected || !detail) return
    setBusy(true)
    try {
      const args: Record<string, unknown> = {}
      for (const p of detail.parameters) {
        const v = values[p.name]
        if (v !== undefined && v !== '') args[p.name] = coerce(p.type, v)
      }
      setResult(await api.execute(selected.schema, selected.name, args))
    } catch (e) { toast.error(errMsg(e)); setResult(null) } finally { setBusy(false) }
  }

  const drop = async () => {
    if (!selected || !confirm(`Drop procedure ${selected.schema}.${selected.name}?`)) return
    try { await api.dropProcedure(selected.schema, selected.name); toast.success('Procedure dropped'); newProc(); await load() }
    catch (e) { toast.error(errMsg(e)) }
  }

  const shown = list.filter(p => `${p.schema}.${p.name}`.toLowerCase().includes(filter.toLowerCase()))

  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <Card className="h-fit">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Stored procedures
            <span className="flex gap-1">
              <Button size="icon" variant="ghost" onClick={load} title="Refresh"><RefreshCw /></Button>
              <Button size="icon" variant="ghost" onClick={newProc} title="New procedure"><Plus /></Button>
            </span>
          </CardTitle>
          <CardDescription>Existing procedures in the connected database.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-2">
          <Input placeholder="Filter..." value={filter} onChange={e => setFilter(e.target.value)} />
          <div className="grid max-h-[60vh] gap-1 overflow-auto">
            {shown.length === 0 && <p className="text-sm text-muted-foreground">No procedures found.</p>}
            {shown.map(p => {
              const active = selected?.schema === p.schema && selected.name === p.name
              return (
                <button
                  key={`${p.schema}.${p.name}`}
                  onClick={() => open(p)}
                  className={`flex items-center justify-between rounded-md px-2 py-1.5 text-left text-sm hover:bg-accent ${active ? 'bg-accent font-medium' : ''}`}
                >
                  <span className="truncate">{p.schema}.{p.name}</span>
                  <Badge variant="secondary">{p.parameterCount}</Badge>
                </button>
              )
            })}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4">
        <Card>
          <CardHeader>
            <CardTitle>{selected ? `${selected.schema}.${selected.name}` : 'New procedure'}</CardTitle>
            <CardDescription>Write or edit T-SQL (CREATE / CREATE OR ALTER / ALTER PROCEDURE) and save it to the database.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-3">
            <Textarea
              value={script}
              onChange={e => setScript(e.target.value)}
              spellCheck={false}
              rows={14}
              className="font-mono text-xs"
            />
            <div className="flex gap-2">
              <Button onClick={save} disabled={busy}><Save /> Save to database</Button>
              {selected && <Button variant="destructive" onClick={drop}><Trash2 /> Drop</Button>}
            </div>
          </CardContent>
        </Card>

        {selected && detail && (
          <Card>
            <CardHeader>
              <CardTitle>Execute</CardTitle>
              <CardDescription>
                Leave a parameter empty to use its default. Type <code>null</code> to pass NULL.
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4">
              {detail.parameters.length > 0 && (
                <div className="grid gap-3 sm:grid-cols-2">
                  {detail.parameters.map(p => (
                    <Field key={p.name} label={`${p.name} · ${p.type}${p.isOutput ? ' · OUTPUT' : ''}${p.hasDefault ? ' · optional' : ''}`}>
                      <Input
                        value={values[p.name] ?? ''}
                        onChange={e => setValues(v => ({ ...v, [p.name]: e.target.value }))}
                        placeholder={p.hasDefault ? '(default)' : p.isOutput ? '(output)' : ''}
                      />
                    </Field>
                  ))}
                </div>
              )}
              <div><Button onClick={run} disabled={busy}><Play /> Execute &amp; convert to JSON</Button></div>
              {result && <ExecutionView result={result} />}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
