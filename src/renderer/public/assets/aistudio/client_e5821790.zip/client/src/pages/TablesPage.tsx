import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { FileJson, Plus, RefreshCw, Trash2, Upload, X } from 'lucide-react'
import { toast } from 'sonner'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { api, type ColumnDef, type ResultSet, type TableInfo } from '@/lib/api'
import { DataGrid, errMsg, Field, NativeSelect } from '@/components/shared'

// ---------------------------------------------------------------------------
const TYPES = [
  'int', 'bigint', 'smallint', 'tinyint', 'bit', 'decimal', 'float', 'real', 'money',
  'nvarchar', 'varchar', 'nchar', 'char', 'date', 'datetime', 'datetime2', 'time',
  'uniqueidentifier', 'varbinary',
]
const SIZE_HINT: Record<string, string> = {
  nvarchar: 'length or max', varchar: 'length or max', varbinary: 'length or max', nchar: 'length', char: 'length',
  decimal: 'p,s e.g. 18,2', datetime2: 'scale 0-7', time: 'scale 0-7',
}
const DEFAULT_SIZE: Record<string, string> = { nvarchar: '255', varchar: '255', varbinary: 'max', nchar: '10', char: '10', decimal: '18,2' }

interface Draft {
  id: number
  name: string; type: string; size: string
  nullable: boolean; primaryKey: boolean; identity: boolean; unique: boolean
  default: string; check: string; refTable: string; refColumn: string
}

let nextId = 1
const blank = (): Draft => ({
  id: nextId++, name: '', type: 'int', size: '', nullable: true, primaryKey: false, identity: false,
  unique: false, default: '', check: '', refTable: '', refColumn: '',
})

function toDef(d: Draft): ColumnDef {
  const def: ColumnDef = {
    name: d.name, type: d.type, nullable: d.nullable, primaryKey: d.primaryKey, identity: d.identity, unique: d.unique,
    default: d.default.trim() || null, check: d.check.trim() || null,
  }
  const size = d.size.trim() || DEFAULT_SIZE[d.type] || ''
  if (['nvarchar', 'varchar', 'varbinary', 'nchar', 'char'].includes(d.type)) def.length = size
  if (d.type === 'decimal') { const [p, s] = size.split(','); def.precision = Number(p) || 18; def.scale = Number(s ?? 2) }
  if (['datetime2', 'time'].includes(d.type) && size) def.scale = Number(size)
  if (d.refTable && d.refColumn) {
    const [schema, table] = d.refTable.split('.')
    def.references = { schema, table, column: d.refColumn }
  }
  return def
}

function fromDef(c: ColumnDef): Draft {
  let size = c.length ?? ''
  if (c.type === 'decimal') size = `${c.precision ?? 18},${c.scale ?? 2}`
  return {
    ...blank(), name: c.name, type: c.type, size, nullable: c.nullable, primaryKey: c.primaryKey,
    identity: c.identity, unique: c.unique,
  }
}

/** Accepts [..], {..} or {"anything": [..]} and returns the list of row objects. */
function parseRows(text: string): Record<string, unknown>[] {
  const v = JSON.parse(text)
  if (Array.isArray(v)) return v
  if (v && typeof v === 'object') {
    const arrays = Object.values(v).filter(Array.isArray)
    if (arrays.length === 1) return arrays[0] as Record<string, unknown>[]
    return [v as Record<string, unknown>]
  }
  throw new Error('JSON must be an array of objects')
}

function readFile(file: File) {
  return new Promise<string>((res, rej) => {
    const r = new FileReader()
    r.onload = () => res(String(r.result))
    r.onerror = () => rej(r.error)
    r.readAsText(file)
  })
}

// ---------------------------------------------------------------------------
function TableBuilder({ tables, onCreated }: { tables: TableInfo[]; onCreated: (name: string) => void }) {
  const [schema, setSchema] = useState('dbo')
  const [name, setName] = useState('')
  const [cols, setCols] = useState<Draft[]>([
    { ...blank(), name: 'Id', type: 'int', nullable: false, primaryKey: true, identity: true },
    { ...blank(), name: 'Name', type: 'nvarchar', size: '100', nullable: false },
  ])
  const [pendingRows, setPendingRows] = useState<Record<string, unknown>[] | null>(null)
  const [sql, setSql] = useState('')
  const [sqlError, setSqlError] = useState('')
  const [busy, setBusy] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  const update = (id: number, patch: Partial<Draft>) => setCols(cs => cs.map(c => (c.id === id ? { ...c, ...patch } : c)))

  const payload = useMemo(() => ({ schema, name, columns: cols.map(toDef) }), [schema, name, cols])

  useEffect(() => {
    if (!name.trim()) { setSql(''); setSqlError(''); return }
    const h = setTimeout(async () => {
      try { setSql((await api.previewTable(payload)).sql); setSqlError('') }
      catch (e) { setSql(''); setSqlError(errMsg(e)) }
    }, 350)
    return () => clearTimeout(h)
  }, [payload, name])

  const fromJsonFile = async (file: File) => {
    try {
      const rows = parseRows(await readFile(file))
      const inferred = await api.infer(rows)
      setCols(inferred.map(fromDef))
      setPendingRows(rows)
      if (!name.trim()) setName(file.name.replace(/\.[^.]+$/, '').replace(/[^\w ]/g, '_'))
      toast.success(`Inferred ${inferred.length} columns from ${rows.length} rows - review them below`)
    } catch (e) { toast.error(errMsg(e)) }
  }

  const create = async () => {
    setBusy(true)
    try {
      await api.createTable(payload)
      let msg = `Table ${schema}.${name} created`
      if (pendingRows?.length) {
        try {
          const r = await api.importRows(schema, name, pendingRows)
          msg += ` and ${r.inserted} rows imported`
        } catch (e) { toast.error(`Table created, but import failed: ${errMsg(e)}`) }
      }
      toast.success(msg)
      onCreated(`${schema}.${name}`)
    } catch (e) { toast.error(errMsg(e)) } finally { setBusy(false) }
  }

  const refCols = (t: string) => tables.find(x => `${x.schema}.${x.name}` === t)?.columns ?? []

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create a table</CardTitle>
        <CardDescription>Define the name, columns and constraints, or start from a JSON file and let the columns be inferred.</CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4">
        <div className="grid gap-3 sm:grid-cols-[120px_1fr_auto]">
          <Field label="Schema"><Input value={schema} onChange={e => setSchema(e.target.value)} /></Field>
          <Field label="Table name"><Input value={name} onChange={e => setName(e.target.value)} placeholder="Customers" /></Field>
          <div className="flex items-end">
            <input
              ref={fileRef} type="file" accept=".json,application/json" className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) void fromJsonFile(f); e.target.value = '' }}
            />
            <Button variant="outline" onClick={() => fileRef.current?.click()}><FileJson /> Infer from JSON file</Button>
          </div>
        </div>

        {pendingRows && (
          <div className="flex items-center justify-between rounded-lg border bg-muted/40 px-3 py-2 text-sm">
            <span>{pendingRows.length} rows from the file will be imported after the table is created.</span>
            <Button size="sm" variant="ghost" onClick={() => setPendingRows(null)}><X /> Don't import</Button>
          </div>
        )}

        <div className="grid gap-3">
          {cols.map(c => (
            <div key={c.id} className="grid gap-2 rounded-lg border p-3">
              <div className="grid gap-2 sm:grid-cols-[1fr_150px_150px_auto]">
                <Input placeholder="Column name" value={c.name} onChange={e => update(c.id, { name: e.target.value })} />
                <NativeSelect value={c.type} onChange={e => update(c.id, { type: e.target.value, size: '' })}>
                  {TYPES.map(t => <option key={t}>{t}</option>)}
                </NativeSelect>
                <Input
                  placeholder={SIZE_HINT[c.type] ?? 'size n/a'} disabled={!SIZE_HINT[c.type]}
                  value={c.size} onChange={e => update(c.id, { size: e.target.value })}
                />
                <Button size="icon" variant="ghost" onClick={() => setCols(cs => cs.filter(x => x.id !== c.id))} title="Remove column"><X /></Button>
              </div>
              <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm">
                <label className="flex items-center gap-2"><Checkbox checked={c.primaryKey} onCheckedChange={v => update(c.id, { primaryKey: !!v })} /> Primary key</label>
                <label className="flex items-center gap-2"><Checkbox checked={c.identity} onCheckedChange={v => update(c.id, { identity: !!v })} /> Identity</label>
                <label className="flex items-center gap-2"><Checkbox checked={c.nullable && !c.primaryKey && !c.identity} disabled={c.primaryKey || c.identity} onCheckedChange={v => update(c.id, { nullable: !!v })} /> Allow NULL</label>
                <label className="flex items-center gap-2"><Checkbox checked={c.unique} onCheckedChange={v => update(c.id, { unique: !!v })} /> Unique</label>
              </div>
              <div className="grid gap-2 sm:grid-cols-4">
                <Input placeholder="Default e.g. 0, 'n/a', GETDATE()" value={c.default} onChange={e => update(c.id, { default: e.target.value })} />
                <Input placeholder="Check e.g. Age >= 0" value={c.check} onChange={e => update(c.id, { check: e.target.value })} />
                <NativeSelect value={c.refTable} onChange={e => update(c.id, { refTable: e.target.value, refColumn: '' })}>
                  <option value="">Foreign key: none</option>
                  {tables.map(t => <option key={`${t.schema}.${t.name}`} value={`${t.schema}.${t.name}`}>{t.schema}.{t.name}</option>)}
                </NativeSelect>
                <NativeSelect value={c.refColumn} disabled={!c.refTable} onChange={e => update(c.id, { refColumn: e.target.value })}>
                  <option value="">column...</option>
                  {refCols(c.refTable).map(rc => <option key={rc.name}>{rc.name}</option>)}
                </NativeSelect>
              </div>
            </div>
          ))}
          <div><Button variant="outline" size="sm" onClick={() => setCols(cs => [...cs, blank()])}><Plus /> Add column</Button></div>
        </div>

        <div className="grid gap-1">
          <span className="text-xs font-medium text-muted-foreground">SQL preview</span>
          {sqlError
            ? <p className="text-sm text-destructive">{sqlError}</p>
            : <pre className="overflow-auto rounded-lg border bg-muted/40 p-3 font-mono text-xs">{sql || '-- enter a table name'}</pre>}
        </div>

        <div><Button onClick={create} disabled={busy || !!sqlError || !sql}>Create table{pendingRows ? ' & import rows' : ''}</Button></div>
      </CardContent>
    </Card>
  )
}

// ---------------------------------------------------------------------------
function TableDetail({ table, onChanged, onDropped }: { table: TableInfo; onChanged: () => void; onDropped: () => void }) {
  const [rows, setRows] = useState<ResultSet | null>(null)
  const [values, setValues] = useState<Record<string, string>>({})
  const [jsonText, setJsonText] = useState('')
  const [busy, setBusy] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  const loadRows = useCallback(async () => {
    try { setRows(await api.rows(table.schema, table.name, 100)) } catch (e) { toast.error(errMsg(e)) }
  }, [table.schema, table.name])
  useEffect(() => { setValues({}); setJsonText(''); void loadRows() }, [loadRows])

  const writable = table.columns.filter(c => !c.identity && !c.computed)

  const addRow = async () => {
    setBusy(true)
    try {
      const body: Record<string, unknown> = {}
      for (const c of writable) {
        const v = values[c.name]
        if (v === undefined || v === '') continue
        body[c.name] = v.toLowerCase() === 'null' ? null : v
      }
      await api.insertRow(table.schema, table.name, body)
      toast.success('Row added')
      setValues({})
      await loadRows(); onChanged()
    } catch (e) { toast.error(errMsg(e)) } finally { setBusy(false) }
  }

  const importJson = async (text: string) => {
    setBusy(true)
    try {
      const r = await api.importRows(table.schema, table.name, parseRows(text))
      toast.success(`${r.inserted} rows imported`)
      setJsonText('')
      await loadRows(); onChanged()
    } catch (e) { toast.error(errMsg(e)) } finally { setBusy(false) }
  }

  const drop = async () => {
    if (!confirm(`Drop table ${table.schema}.${table.name} and all its data?`)) return
    try { await api.dropTable(table.schema, table.name); toast.success('Table dropped'); onDropped() }
    catch (e) { toast.error(errMsg(e)) }
  }

  return (
    <div className="grid gap-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            {table.schema}.{table.name}
            <Button size="sm" variant="destructive" onClick={drop}><Trash2 /> Drop table</Button>
          </CardTitle>
          <CardDescription>{table.rowCount} rows</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-2">
          {table.columns.map(c => (
            <div key={c.name} className="flex flex-wrap items-center gap-2 text-sm">
              <span className="font-medium">{c.name}</span>
              <span className="text-muted-foreground">{c.type}</span>
              {c.primaryKey && <Badge>PK</Badge>}
              {c.identity && <Badge variant="secondary">IDENTITY</Badge>}
              {c.unique && <Badge variant="secondary">UNIQUE</Badge>}
              {!c.nullable && <Badge variant="outline">NOT NULL</Badge>}
              {c.default && <Badge variant="outline">DEFAULT {c.default}</Badge>}
              {c.references && <Badge variant="outline">FK → {c.references}</Badge>}
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Data <Button size="icon" variant="ghost" onClick={loadRows} title="Refresh"><RefreshCw /></Button>
          </CardTitle>
          <CardDescription>First 100 rows.</CardDescription>
        </CardHeader>
        <CardContent>{rows && <DataGrid set={rows} />}</CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Add a row</CardTitle>
          <CardDescription>Empty fields use the column default (or NULL). Identity columns are filled automatically.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3">
          <div className="grid gap-3 sm:grid-cols-2">
            {writable.map(c => (
              <Field key={c.name} label={`${c.name} · ${c.type}${c.nullable ? '' : ' · required'}`}>
                <Input value={values[c.name] ?? ''} onChange={e => setValues(v => ({ ...v, [c.name]: e.target.value }))} />
              </Field>
            ))}
          </div>
          <div><Button onClick={addRow} disabled={busy}><Plus /> Insert row</Button></div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Import from JSON</CardTitle>
          <CardDescription>
            An array of objects whose keys match the column names, e.g. <code>{'[{"Name":"Ann","Age":30}]'}</code>.
            The import is all-or-nothing.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3">
          <Textarea rows={6} value={jsonText} onChange={e => setJsonText(e.target.value)} className="font-mono text-xs" placeholder="Paste JSON here or choose a file" />
          <div className="flex gap-2">
            <input
              ref={fileRef} type="file" accept=".json,application/json" className="hidden"
              onChange={async e => { const f = e.target.files?.[0]; if (f) setJsonText(await readFile(f)); e.target.value = '' }}
            />
            <Button variant="outline" onClick={() => fileRef.current?.click()}><Upload /> Choose JSON file</Button>
            <Button onClick={() => importJson(jsonText)} disabled={busy || !jsonText.trim()}>Import rows</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ---------------------------------------------------------------------------
export function TablesPage({ refreshKey }: { refreshKey: number }) {
  const [tables, setTables] = useState<TableInfo[]>([])
  const [selected, setSelected] = useState<string | 'new'>('new')

  const load = useCallback(async () => {
    try { setTables(await api.tables()) } catch (e) { toast.error(errMsg(e)); setTables([]) }
  }, [])
  useEffect(() => { void load() }, [load, refreshKey])

  const current = tables.find(t => `${t.schema}.${t.name}` === selected)

  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <Card className="h-fit">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Tables
            <span className="flex gap-1">
              <Button size="icon" variant="ghost" onClick={load} title="Refresh"><RefreshCw /></Button>
              <Button size="icon" variant="ghost" onClick={() => setSelected('new')} title="New table"><Plus /></Button>
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-1">
          {tables.length === 0 && <p className="text-sm text-muted-foreground">No tables yet.</p>}
          {tables.map(t => {
            const key = `${t.schema}.${t.name}`
            return (
              <button
                key={key} onClick={() => setSelected(key)}
                className={`flex items-center justify-between rounded-md px-2 py-1.5 text-left text-sm hover:bg-accent ${selected === key ? 'bg-accent font-medium' : ''}`}
              >
                <span className="truncate">{key}</span>
                <Badge variant="secondary">{t.rowCount}</Badge>
              </button>
            )
          })}
        </CardContent>
      </Card>

      {current
        ? <TableDetail key={selected} table={current} onChanged={load} onDropped={async () => { setSelected('new'); await load() }} />
        : <TableBuilder tables={tables} onCreated={async key => { await load(); setSelected(key) }} />}
    </div>
  )
}
